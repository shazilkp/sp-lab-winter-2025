#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>


int n,my_index,children[100];
int status;

void handle_exit(int sig){
	//printf("hello boys \n");
	fflush(stdout);
	if(status == 0){
		printf("\nChild %d: Yay! I am the winner\n",my_index+1);
		fflush(stdout);
	}
	exit(0);
}

void catch_or_miss(int sig){
	if(sig == SIGUSR2){
		int success = (rand() % 100) < 80;
		if(success){
			//fprintf(stderr,"Child %d: CATCH\n", my_index + 1);
            		fflush(stdout);
            		status = 1;
			kill(getppid(),SIGUSR1);	//parent knows ball was catched
		}
		else{
			//fprintf(stderr,"Child %d: MISS\n", my_index + 1);
          		fflush(stdout);
          		status = 2;
			kill(getppid(), SIGUSR2);  // Notify parent that the ball was missed
			//exit(0);
		}
	}

}

void print_status(int sig){
	//fprintf(stderr,"print signal recieved to %d\n",my_index+1);
	if(sig == SIGUSR1){
		switch(status){
			case 0:{
				printf("....     ");
				fflush(stdout);
				break;
			}
			case 1:{
				printf("CATCH    ");
				status=0;
				fflush(stdout);
				break;
			}
			case 2:{
				printf("MISS     ");
				status=3;
				fflush(stdout);
				break;
			}
			case 3:{
				printf("         ");
				fflush(stdout);
				break;
			}
			default:{
				printf("Error    ");
				fflush(stdout);
			}
		}

	}
	if(my_index != n-1){
		kill(children[my_index+1], SIGUSR1);
	}
	else{
		FILE *fp = fopen("dummycpid.txt", "r");
		int dummy_pid;
		fscanf(fp, "%d", &dummy_pid);
		fclose(fp);
		kill(dummy_pid, SIGINT);
	}
}


void initialize_my_index() {
	FILE *fp = fopen("childpid.txt", "r");
	if (!fp) {
		perror("Error opening childpid.txt");
		exit(1);
	}
	
	fscanf(fp, "%d", &n);  // Read number of children
	for (int i = 0; i < n; i++) {
		fscanf(fp, "%d", &children[i]);  // Read each child PID
		if (children[i] == getpid()) {
			my_index = i;  // Find our own index
		}
	}

	fclose(fp);
}

int main(){
	sleep(1);
	initialize_my_index();
	srand(getpid());
	//sleep(1);
	status = 0;
	
	/*
	FILE * fd = fopen("childpid.txt","r");
	int bufferLength = 255;
	char buffer[bufferLength];
	
	while(fgets(buffer, bufferLength, fd)) {
		printf("%s\n", buffer);
	}
	*/
	//initialize_my_index();
	
	signal(SIGUSR2, catch_or_miss);
	signal(SIGUSR1, print_status);
	signal(SIGINT, handle_exit);
	//printf("child %d\n",my_index+1);
	fflush(stdout);
	
	while(1){
	/*
		if(status != 2){
			status = 0;		//reset status to playing if not missed in prev rounf
		}
		else{
			status = 3;
		}
		*/
		pause();
		
		
		
		//printf("Status of %d: %d\n",my_index+1,status);
	}
}
