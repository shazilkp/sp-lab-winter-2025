#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void handle_exit(int sig) {
    exit(0);
}

int main() {
    signal(SIGINT, handle_exit);
    while (1) {
        pause();
    }
    return 0;
}
