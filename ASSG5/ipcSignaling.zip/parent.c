#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

#define MAX_CHILDREN 100

int f_return[MAX_CHILDREN];
int active[MAX_CHILDREN];
int last_throw;
int n;

void handle_miss(int sig){
	for (int i = 0; i < n; i++) {
        if (f_return[i] == last_throw) {  // The last thrown child missed
            active[i] = 0;  // Child is out
            break;
        }
    }
}

void handle_catch(int sig) {
    // Child caught the ball, no need to change `active[]`
}

int main(int argc, char ** argv){
	n = atoi(argv[1]);
	
	
	signal(SIGUSR1, handle_catch);
	signal(SIGUSR2, handle_miss);
	
	for(int i = 0 ; i < n ; i++){
		f_return[i] = fork();
		if(f_return[i] == 0){
			//our consumer code
			execlp("./child", "child", (char *)NULL);
			exit(0);	
		}
		active[i] = 1;
	}
	
	for(int i = 0 ; i < n ; i++){
		printf("%d ",f_return[i]);
	}
	printf("\n");
	
	
	FILE * fd = fopen("childpid.txt","w");
	fprintf(fd,"%d\n",n);
	for(int i = 0 ;i < n ; i++){
		fprintf(fd,"%d\n",f_return[i]);
	}
	fflush(fd);
	
	sleep(3);
	
	//kill(f_return[0],SIGUSR2);
	
	for(int i = 0 ; i < n ; i++){
			printf("%d        ",i+1);
			      // "CATCH    "
			fflush(stdout);
		}
		printf("\n");
		fflush(stdout);
		
	
	
	int turn = 0;
	int remains = n;
	while(remains > 1){
		while(active[turn] == 0){
			turn = (turn + 1) % n;
		}
		last_throw = f_return[turn];
		
		//fprintf(stderr,"ball thrown to %d\n",turn+1);
		fflush(stdout);
		
		kill(f_return[turn],SIGUSR2);
		
		pause();
		
		
		fflush(stdout);
		printf("\n");
		fflush(stdout);
		
		int dummy = fork();
		if(dummy == 0){
			execl("./dummy", "dummy", NULL);
            		exit(1);
		}
		else{
			FILE * fd1 = fopen("dummycpid.txt","w");
			fprintf(fd1,"%d\n",dummy);
			fclose(fd1);
		}
		
		//printf("CATCH    ....     ....     ....     ....     ....     ....     ....");
		printf("+-----------------------------------------------------------------+\n");
		fflush(stdout);
		kill(f_return[0],SIGUSR1);
		waitpid(dummy, NULL, 0); 
		printf("\n+-----------------------------------------------------------------+\n");
		fflush(stdout);
		
		
		
		
		if(!active[turn]){
			remains--;
		}
		turn = (turn + 1) % n;
	}
	
	
	for(int i = 0; i < n ; i++){
		//printf("trying to send kill signal\n");
		fflush(stdout);
		kill(f_return[i],SIGINT);
	}
	
	
}


